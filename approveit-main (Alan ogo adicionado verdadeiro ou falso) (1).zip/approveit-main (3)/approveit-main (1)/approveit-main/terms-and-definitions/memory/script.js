let currentQuestionIndex = 0;
let score = 0;
let questionData = [];
let currentTimer = 0;

const correctSound = new Audio("../sounds/bell.wav");
const wrongSound = new Audio("../sounds/caught.wav");
const flipSound = new Audio("../sounds/select.wav");

const fileDropdown = document.getElementById("file-dropdown");
const optionsContainer = document.getElementById("options");
const feedback = document.getElementById("feedback");
const questionElem = document.getElementById("question");
const scoreElem = document.getElementById("score");
const nextBtn = document.getElementById("nextBtn");
const timerElem = document.getElementById("timer");

let timerSeconds = 0;
let timer;

fileDropdown.addEventListener("change", loadQuestions);

// Função para carregar as questões a partir do arquivo selecionado
function loadQuestions() {
    const fileName = fileDropdown.value;
    
    if (!fileName) {
        alert("Por favor, selecione um arquivo de dados.");
        return;
    }

    // Usar a função modificada de commons.js para carregar o arquivo JSON
    loadQuestionsFromCommons(fileName);
    
    score = 0;
    currentQuestionIndex = 0;
    resetTimer();
    startTimer();
    loadNextQuestion();
}

// Função para carregar a próxima questão
function loadNextQuestion() {
    if (currentQuestionIndex >= questionData.length) {
        endQuiz();
        return;
    }

    const currentQuestion = questionData[currentQuestionIndex];
    questionElem.innerText = `O que significa \"${currentQuestion.term}\"?`;

    const options = generateOptions(currentQuestion);
    optionsContainer.innerHTML = "";

    options.forEach(option => {
        const optionElement = document.createElement("div");
        optionElement.classList.add("option");
        optionElement.innerText = option.definition;
        optionElement.onclick = () => checkAnswer(option.definition, currentQuestion.definition);
        optionsContainer.appendChild(optionElement);
    });

    nextBtn.style.display = "none";
}

// Função para verificar a resposta
function checkAnswer(selectedAnswer, correctAnswer) {
    if (selectedAnswer === correctAnswer) {
        feedback.innerText = "Correto!";
        feedback.style.color = "#4CAF50";
        score++;
        correctSound.play();
    } else {
        feedback.innerText = "Errado! Tente novamente.";
        feedback.style.color = "#f56a79";
        wrongSound.play();
    }

    scoreElem.innerText = `Pontuação: ${score}`;
    nextBtn.style.display = "block";
    currentQuestionIndex++;
}

// Gerar opções para a questão
function generateOptions(currentQuestion) {
    const incorrectDefinitions = questionData.filter(q => q.term !== currentQuestion.term)
                                             .map(q => q.definition);
    const shuffledIncorrect = shuffle(incorrectDefinitions).slice(0, 3);
    const options = [{
        term: currentQuestion.term,
        definition: currentQuestion.definition
    }, ...shuffledIncorrect.map(def => ({ term: "???", definition: def }))];
    return shuffle(options);
}

// Finalizar o quiz
function endQuiz() {
    resetTimer();
    alert(`Quiz finalizado! Sua pontuação final foi: ${score}`);
    feedback.innerText = "";
    questionElem.innerText = "Selecione um novo arquivo para jogar novamente.";
    optionsContainer.innerHTML = "";
}

// Funções auxiliares
function shuffle(array) {
    let currentIndex = array.length, randomIndex;

    while (currentIndex !== 0) {
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex--;

        [array[currentIndex], array[randomIndex]] = [array[randomIndex], array[currentIndex]];
    }

    return array;
}

function startTimer() {
    timer = setInterval(() => {
        timerSeconds++;
        const minutes = Math.floor(timerSeconds / 60);
        const seconds = timerSeconds % 60;
        timerElem.innerText = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
    }, 1000);
}

function resetTimer() {
    clearInterval(timer);
    timerSeconds = 0;
    timerElem.innerText = "00:00";
}

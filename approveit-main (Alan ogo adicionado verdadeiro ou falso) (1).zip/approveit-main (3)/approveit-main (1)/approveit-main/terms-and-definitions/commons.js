// Função para carregar os arquivos JSON no dropdown
function loadFileList(element) {
  const files = [
      { name: "../data/chess.json", label: "Xadrez" },
      { name: "../data/actions.json", label: "Ações" },
      { name: "../data/ing-family-short.json", label: "Palavras -ing" },
      { name: "../data/trueoufalse.json", label: "Verdadeiro ou Falso" },
  ];

  files.forEach(file => {
      const option = document.createElement("option");
      option.value = file.name;
      option.textContent = file.label;
      element.appendChild(option);
  });
}

// Função para carregar o arquivo JSON escolhido
function loadQuestionsFromCommons(fileName) {
  fetch(fileName)
      .then(response => response.json())
      .then(data => {
          // Limpa qualquer conteúdo antigo
          const questionContainer = document.getElementById('questionContainer');
          questionContainer.innerHTML = '';  // Limpa perguntas anteriores
          displayQuestion(data);
      })
      .catch(error => console.error('Erro ao carregar o arquivo:', error));
}

// Função para exibir as perguntas e opções
function displayQuestion(data) {
  const questionContainer = document.getElementById('questionContainer');
  const question = data[0];  // Aqui assumimos que estamos exibindo a primeira pergunta
  const questionText = document.createElement('p');
  questionText.textContent = question.term;
  questionContainer.appendChild(questionText);

  // Criação de botões para cada opção
  question.options.forEach(option => {
      const button = document.createElement('button');
      button.textContent = option;
      button.onclick = () => checkAnswer(option, question.definition);
      questionContainer.appendChild(button);
  });
}

// Função para verificar a resposta
function checkAnswer(selectedOption, correctAnswer) {
  if (selectedOption === correctAnswer) {
      alert('Resposta correta!');
  } else {
      alert('Resposta incorreta!');
  }
}

let timerSeconds = 0;
let timer;

// Função para iniciar o cronômetro
function startTimer(element) {
  timer = setInterval(() => {
      timerSeconds++;
      const minutes = Math.floor(timerSeconds / 60);
      const seconds = timerSeconds % 60;
      element.innerText = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  }, 1000);
}

function resetTimer() {
  clearInterval(timer);
  timerSeconds = 0;
}

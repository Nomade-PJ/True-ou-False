document.addEventListener("DOMContentLoaded", () => {
    let terms = [];
    let currentTerm = null;
    let score = 0;
    let questionCount = 0;
    let timerInterval;
    let timeLeft = 30;

    const termElement = document.getElementById("term");
    const scoreElement = document.getElementById("score");
    const feedbackDisplay = document.getElementById("feedback");
    const optionsContainer = document.getElementById("options");
    const restartButton = document.getElementById("restart-btn");
    const fileDropdown = document.getElementById("file-dropdown");
    const timerDisplay = document.getElementById("timer");

    // Sons de feedback
    const correctSound = new Audio("../sounds/bell.wav");
    const wrongSound = new Audio("../sounds/caught.wav");

    // Carregar lista de arquivos
    loadFileList(fileDropdown);

    // Carregar um arquivo JSON selecionado
    fileDropdown.addEventListener("change", (event) => {
        const selectedFile = event.target.value;
        if (selectedFile) {
            fetch(selectedFile)
                .then(response => response.json())
                .then(data => {
                    terms = data;
                    restartGame(); // Reinicia o jogo com os novos termos
                })
                .catch(error => console.error("Erro ao carregar arquivo:", error));
        }
    });

    // Função para reiniciar o temporizador
    function resetTimer() {
        clearInterval(timerInterval);
        timeLeft = 30;
        timerDisplay.textContent = `Tempo: ${timeLeft}s`;
        timerInterval = setInterval(() => {
            timeLeft--;
            timerDisplay.textContent = `Tempo: ${timeLeft}s`;
            if (timeLeft <= 0) {
                clearInterval(timerInterval);
                checkAnswer(""); // Se o tempo acabar, considera como erro
            }
        }, 1000);
    }

    // Carregar uma nova pergunta
    function loadNewTerm() {
        if (questionCount >= terms.length) {
            endGame();
            return;
        }

        // Seleciona uma pergunta aleatória
        const randomIndex = Math.floor(Math.random() * terms.length);
        currentTerm = terms[randomIndex];
        termElement.textContent = currentTerm.term;
        optionsContainer.innerHTML = ""; // Limpa as opções anteriores

        // Cria os botões de opções
        currentTerm.options.forEach((option, index) => {
            const button = document.createElement("button");
            button.classList.add("btn");
            button.textContent = option;
            button.addEventListener("click", () => checkAnswer(option));  // Passa a opção clicada diretamente
            optionsContainer.appendChild(button);
        });

        questionCount++;
        resetTimer(); // Reinicia o temporizador a cada nova pergunta
    }

    // Verificar a resposta
    function checkAnswer(selectedOption) {
        if (currentTerm) {
            const isCorrect = selectedOption === currentTerm.definition;  // Compara com a definição
            if (isCorrect) {
                score++;
                feedbackDisplay.textContent = "Correto!";
                feedbackDisplay.style.color = "green";
                correctSound.play();  // Toca o som de "Correto"
            } else {
                feedbackDisplay.textContent = "Incorreto!";
                feedbackDisplay.style.color = "red";
                wrongSound.play();  // Toca o som de "Incorreto"
            }
            scoreElement.textContent = `Pontuação: ${score}`;
        }

        setTimeout(() => {
            feedbackDisplay.textContent = ""; // Limpar feedback após 1 segundo
            loadNewTerm(); // Carregar a próxima pergunta
        }, 1000);
    }

    // Reiniciar o jogo
    function restartGame() {
        score = 0;
        questionCount = 0;
        scoreElement.textContent = "Pontuação: 0";
        feedbackDisplay.textContent = "";
        termElement.textContent = "Carregando perguntas...";
        loadNewTerm();
    }

    // Finalizar o jogo
    function endGame() {
        alert(`Jogo finalizado! Sua pontuação foi: ${score}/${terms.length}`);
        restartGame();
    }

    // Eventos do botão de reiniciar
    restartButton.addEventListener("click", restartGame);
});

